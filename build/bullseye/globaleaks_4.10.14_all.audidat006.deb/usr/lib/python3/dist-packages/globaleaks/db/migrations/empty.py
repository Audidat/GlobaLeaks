from globaleaks.db.migrations.update import MigrationBase as MigrationScript
